	package Base;
	
	public class Point {
		public int x;
		public int y;
		Point(){};
		public Point(int x,int y){
			this.x = x;
			this.y = y;
		}
	}
